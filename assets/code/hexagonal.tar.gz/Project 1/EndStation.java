import java.util.*;
/**
 * @(#)EndStation.java
 *
 *
 * @author Jason Ernst
 * @description EndStation class, represents the location of an EndStation in the world grid
 *  of the simulation
 * @version 1.00 2008/3/15
 */
public class EndStation 
{
	private double x;
	private double y;
	
	/*
	 * Constructs a new packet using x and y
	 */
    public EndStation() 
    {
  		Random rand = new Random();
    	x = rand.nextDouble() * Simulation.MAX_X; //Uniform random distribution to generate x and y coords
		  y = rand.nextDouble() * Simulation.MAX_Y;
    }
    
    public void display()
    {
    	System.out.println("End Station -> X: " + x + " Y:" + y);
    }
    
    /*
     * Accessor method to return x
     */
    public double getX()
    {
    	return x;
    }
    
    /*
     * Accessor method to return y
     */
    public double getY()
    {
    	return y;
    }
}
