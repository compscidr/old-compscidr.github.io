import java.util.*;

/**
 * @(#)BaseStation.java
 *
 * @author Jason Ernst
 * @description Class to represent the BaseStations of a wireless network
 * for a simulation
 * @version 1.00 2008/3/15
 */
public class BaseStation 
{	
	public static final int MAX_NEIGHBOURS = 6; //depends on the geometry of the network.
																							//6 = hexagons
	private int id;
	private int[] neighbours = new int[MAX_NEIGHBOURS];
	private int destination_buffer;
	private double x;
	private double y;
	
	  /*
	   * Constructs a new BaseStation with the given id and x,y coords in the world
	   * with no neighbours initially
	   * @param id the id of the BS
	   * @param x the x-coordinate of the BS in the world
	   * @param y the y-coordinate of the BS in the world
	   */
    public BaseStation(int id, double x, double y) 
    {
    	this.id = id;			 //id of bs
    	this.x = x;				 //Set location of the base station
    	this.y = y;				 
    	destination_buffer = -1; //Set destination buffer to be empty
    	
    	//set neighbours to null to initialize
    	int count=0;
    	while(count<MAX_NEIGHBOURS)
    	{
    	  neighbours[count]=-1;
    	  count++;
      }
    }
    
    /*
     * Displays the info about the baseStation for debugging
     */
    public void display()
    {}
    
    /*
     * Method to display the neighbours of the BS
     */
    private void displayNeighbours()
    {
      int count=0;
      while(count < MAX_NEIGHBOURS && neighbours[count]!=-1)
      {
        System.out.print(" " + neighbours[count]);
        count++;
      }
    }
    
    /* 
     * Adds a neighbour to the neighbour array of the BS
     * @param id the id of the neighbour BS to become a neighbour
     * @return the id of the neighbour that was successfully added or
     * if unsuccessful, -1
     */
    public int addNeighbour(int id)
    {
    	int x=0;
    	//Loop through neighbours array until we find a free spot
    	while(x<MAX_NEIGHBOURS)
    	{
    		if(neighbours[x]==-1)
    		{
    			neighbours[x]=id;
    			return id;
    		}
    		else
    			x++;
    	}
    	return -1;
    }
    
    /* 
     * Accessor method to get the id of the BS
     * @return the id of the BS
     */
    public int getId()
    { return id; }
    
    /*
     * Accessor method to get the X coordinate of the BS in the world
     * @return the X-coordinate of the BS in the world
     */
    public double getX()
    { return x; }
    
    /*
     * Accessor method to get the Y coordinate of the BS in the world
     * @return the Y-coordinate of the BS in the world
     */
    public double getY()
    { return y; }
    
    /*
     * Attempts to set the destination_buffer of the BS
     * @param id the id of the destination BS to be put in the buffer
     * @return the id of the destination BS if successfully set, othewise -1
     */
    public int setBuffer(int id)
    {
    	if(destination_buffer == -1)
    	{
    		destination_buffer = id;
    		return id;
    	}
    	else
    		return -1;
    }
    
    /*
     * Clears the destination buffer, ie) sets it to -1
     */ 
    public void clearBuffer()
    {
      destination_buffer = -1;
    }
    
    /*
     * Attempts to return the id of a random neighbour BS
     * (if no neighbours this method will give an error)
     * @return the id of the random neighbour BS
     */
    public int getRandomNeighbour()
    {
      int count=0;
      
      //check for no neighbours, to prevent infinite loop
      while(count < MAX_NEIGHBOURS && neighbours[count]!=-1)
        count++;
      if(count > 0)
      {
        Random rand = new Random();
        int neighbour = rand.nextInt(MAX_NEIGHBOURS);
      
        while(neighbours[neighbour] == -1)
          neighbour = rand.nextInt(MAX_NEIGHBOURS);
      
        return neighbours[neighbour];
      }
      else
      {
        System.out.println("Error, you tried to find a random neighbour, but the BS has no neighbours");
        System.exit(0);
        return -1;
      }
    }
    
    /*
     * Returns an array of the neighbours ids
     * @return All of the neighbours of the BS in an array of ints
     */
    public int[] getNeighbours()
    { return neighbours; }
    
    /*
     * Returns id of neighbour at array element neighbour
     * @param neighbour the id in the neighbour array
     * @returns the id of the neighbour located in the array position specified
     */
    public int getNeighbour(int neighbour)
    {
      return neighbours[neighbour];
    }
    
    /*
     * Returns the buffer of the BaseStation
     * @return the id of the BS in the destination buffer
     */
    public int getBuffer()
    {
    	return destination_buffer;
    }
}
