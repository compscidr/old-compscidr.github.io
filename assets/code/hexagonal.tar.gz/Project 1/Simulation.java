import java.util.*;

/**
 * @(#)Simulation.java
 *
 * @author Jason Ernst
 * @description CS6650 - Computer Networks: Project 1: Discrete Event Simulation of a hexagonal manhattan street wireless network.
 * @version 2.00 2008/4/12
 */
class Simulation
{
  //constant values
  private final static double MEAN = 1;            //avg time between packets
  private final static int NUM_PACKETS = 10000000;
  
  public static final int MAX_BASESTATIONS = 500; //max # of BS's to allocate memory for
  public final static int MAX_X = 10;             //dimensions of simulation
  public final static int MAX_Y = 5;            
  public static final int INTER_BS_RANGE = 2;		  //distance a BS can communicate with another BS
	public static final int BS_RANGE = 1;			      //distance a BS can communicate with ES
  
  private static final int RANDOM_ROUTING = 1;
  private static final int CARTESIAN_ROUTING = 2;

  //private variables
  private static EventQueue EQ = new EventQueue();
  private static BaseStation bs[] = new BaseStation[MAX_BASESTATIONS];
  private static int routing = RANDOM_ROUTING;

  /*
   * Main Simulation Method
   */
  public static void main(String args[])
  {
    //variables for main
    Event tmp=null; Event min=null;
    double now=0; double delay=0; double highDelay=0; double lowDelay=0;
    int packetCounter=0; int dropCounter=0; int successCounter=0;
      
    System.out.println("Starting Simulation with MEAN = " + MEAN + " ...");
    /********************************************/
    
    //create the basestations and their neighbours
		bs = SimulationTools.generateBSLocations(bs); 
		bs = SimulationTools.generateNeighbours(bs);	
    
    tmp = generatePacket(now);
    EQ.insert(tmp);
    packetCounter++;
    
    //main simulation loop
    //continues until no more events are in the event queue
    while((min=EQ.removeMin())!=null)
    {
      int type = min.getType();
      int source; int destination; int neighbour;
      Random rand = new Random();
      
      now = min.getTime();
      
      source = min.getSource();
      destination = min.getDestination();

      //handle each type of event differently              
      switch(type)
      {
        case Event.HOP:
          //System.out.print("Hop Event: ");
          //min.display();
          
          //we have arrived at dest
          if(source == destination)
          {
            //System.out.println("  DESTINATION REACHED, changing to success event");
            //change type to SUCCESS, increment time and reinsert into queue
            min.setType(Event.SUCCESS);
            min.setTime(min.getTime() + 1);
            EQ.insert(min);
            min.addDelay(1);
          }
          else //hop to neighbour
          {
            //check to make sure BS is free to hop into it
            if(routing == RANDOM_ROUTING)
              neighbour = bs[source].getRandomNeighbour();
            else
              neighbour = SimulationTools.getNearestNeighbour(bs, source, destination);
            if(bs[neighbour].getBuffer()==-1)
            {
              //System.out.println("  Neighbour CLEAR, putting destination into buffer of neighbour");
              bs[neighbour].setBuffer(destination);
              bs[source].clearBuffer();
            
              //increment time, change source and reinsert into queue
              min.setSource(neighbour);
              min.setTime(min.getTime() + 1);
              EQ.insert(min);
              min.addDelay(1);
            } 
            else //timeout 
            {
              //System.out.print("  Neighbour BUSY:");
              if(min.getNumTimeOuts() < 2)
              {
                //System.out.println("timeout");
                double timeout = rand.nextDouble() * 10 + 1; //random timeout from 1 to 10s
                min.addTimeOut(timeout);
                min.setTime(min.getTime() + timeout);
                EQ.insert(min);
              }
              else
              {
                //System.out.println("out of timeouts, changing to drop event");
                //change event type to drop and reinsert into queue
                min.setType(Event.DROP);
                EQ.insert(min); 
              }
            }//end else if buffer is emtpy
          }//end else if source==dest  
        break;
        case Event.NEW_PACKET:
          //System.out.print("New Packet Event: ");
          //min.display();
          
          //check to make sure the BS is free before we fill buffer
          if(bs[source].getBuffer()==-1)
          {
            //System.out.println("  Source CLEAR, putting destination into buffer of source");
            bs[source].setBuffer(destination);
            
            //change type to HOP, increment time and reinsert into queue
            min.setType(Event.HOP);
            min.setTime(min.getTime() + 1);
            EQ.insert(min);
            min.addDelay(1);
          }
          else
          {
            packetCounter--;//remove packet because source is busy
            //System.out.println("  Source BUSY");
          }
        break;
        case Event.SUCCESS:
          //System.out.print("Success Event: ");
          //min.display();
          
          successCounter++;
          bs[source].clearBuffer();
          
          highDelay = highDelay + min.getDelay();
          lowDelay = lowDelay + min.getDelay();
        break;
        case Event.DROP:
          //System.out.print("Drop Event: ");
          //min.display();
          
          dropCounter++;
          bs[source].clearBuffer();
          
          highDelay = highDelay + min.getDelay();
        break;
        default: 
          System.out.println("There was a problem handling the event, most likely an improper event type");
          System.exit(0);
        break;
      }
            
      //Generate new packets
      if(packetCounter < NUM_PACKETS && EQ.isRoom())
      {
        tmp = generatePacket(now);
        EQ.insert(tmp);
        packetCounter++;
      }
    }
    
    /********************************************/
    
    double avgHighDelay = highDelay / (double)packetCounter;
    double avgLowDelay = lowDelay / (double)successCounter;
    double offeredLoad = (double)packetCounter / now;
    double effectiveThroughput = (double)successCounter / now;
    
    System.out.println("Simulation Complete.");
    System.out.println("Total time: " + now);
    System.out.println("Packets Generated: " + packetCounter);
    System.out.println("Success Packets: " + successCounter);
    System.out.println("Dropped Packets: " + dropCounter);
    System.out.println("High delay: " + highDelay + " Avg High Delay: " + avgHighDelay);
    System.out.println("Low delay: " + lowDelay + "Avg Low Delay: " + avgLowDelay);
    System.out.println("Offered Load: " + offeredLoad);
    System.out.println("Effective Throughput: " + effectiveThroughput);
  }
  
  /*
   * Generates new packets at a given time
   * @param now The time the packet should be generated at
   * @return A "NEW_PACKET" event with time now
   */  
  private static Event generatePacket(double now)
  {
    double time = now + poisson(MEAN);;
    int source=SimulationTools.findBaseStation(new EndStation(), bs);
    int destination=SimulationTools.findBaseStation(new EndStation(), bs);
    while(source==destination)
    {
      destination=SimulationTools.findBaseStation(new EndStation(), bs);
    }
    return new Event(time, Event.NEW_PACKET, source, destination);
  }
  
  /*
   * A method to help generate the next arrival time in a simulation using a
   * possion process / exponential distribution
   * @param MEAN the average inter-arrival time for the entire simulation
   * @return The time between the previous event and the current event
   */
  private static double poisson (double MEAN)
 	{
    return ( (-1) * MEAN*Math.log(Math.random()) );
 	}
}
