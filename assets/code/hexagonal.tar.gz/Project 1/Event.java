/**
 * @(#)Event.java
 *
 * @author Jason Ernst
 * @description Representation of Events for the Simulation
 * @version 2.00 2008/4/12
 */
class Event
{
  //define all the types of events
  public static final int HOP = 1;
  public static final int NEW_PACKET = 2;
  public static final int SUCCESS = 3;
  public static final int DROP = 4;

  //variables
  private double time;
  private int type;
  private int source;
  private int destination;
  
  private int numTimeOuts;
  private double delay;
  
  /*
   * Construct a new Event
   * @param time the time the event should occur in the simulation
   * @param type one of the four types of events
   * @param source the id of the source BS
   * @param destination the id of the destination BS
   */
  public Event(double time, int type, int source, int destination)
  {
    this.time = time;
    this.type = type;
    this.source = source;
    this.destination = destination;
    numTimeOuts = 0;
    delay = 0;
  }
  
  /*
   * Diplays all the relevent data for an Event on the screen
   */
  public void display()
  {
    System.out.println("Time: " + time + " Type: " + type + " Source: " + source + " Dest: " + destination + " TimeOuts: " + numTimeOuts + " Delay: " + delay);
  }

  /*
   * Accessor method to get the number of timeouts that have occurred
   * @return the number of timeouts that have occurred
   */
  public int getNumTimeOuts()
  { return numTimeOuts; }
  
  /*
   * Mutator method to increase the amount of delay the event has experienced
   * @param moreDelay the amount of delay to add
   */
  public void addDelay(double moreDelay)
  { delay = delay + moreDelay; }
  
  /*
   * Mutator method which adds delay and incremements the numTimeOuts counter
   * @param moreDelay
   */
  public void addTimeOut(double moreDelay)
  {
    delay = delay + moreDelay;
    numTimeOuts++;
  }
  
  /*
   * Accessor method to get the amount of delay the event has experienced so far
   * @return the delay the event has experienced so far
   */
  public double getDelay()
  { return delay; }
  
  /*
   * Gets the id of the source BS for the event
   * @return the id of the source BS for the event
   */
  public int getSource()
  { return source; }
  
  /*
   * Mutator method to change the source BS for the event
   * @param source the new id of the source BS for the event
   */
  public void setSource(int source)
  { this.source = source; }
  
  /*
   * Accessor method to get the id of the destination BS for the event
   * @return the destination id of the BS for the event
   */
  public int getDestination()
  { return destination; }
  
  /*
   * Mutator method to set the desintation BS for the event
   * @param destination the new destination BS for the event
   */
  public void setDestination(int destination)
  { this.destination = destination; }
  
  /*
   * Accessor method to get the time the event should occur
   * @return the time the event should occur in the simulation
   */
  public double getTime()
  { return time; } 
  
  /*
   * Mutator method to set the time the event should occur
   * @param time the time the event should occur in the simulation
   */
  public void setTime(double time)
  {
    this.time = time;
  }
  
  /*
   * Accessor method to get the type of the event
   * @return the type of event
   */
  public int getType()
  {
    return type;
  }
  
   /*
   * Mutator method to set the type of the event
   * @param type the type of event
   */
  public void setType(int type)
  {
    this.type = type;
  }
}
