/**
 * @(#)SimulationTools.java
 *
 * @author Jason Ernst
 * @description The class provides much of the functionality required for the simulation but separated out of the Simulation
 * class itself to improve readability.
 * @version 2.00 2008/4/12
 */
class SimulationTools
{
  public SimulationTools()
  {}
  
	/*
	 * Finds the id of the BS which is closest to the given EndStation e within the network
	 * @param e the EndStation to associate with a BS
	 * @param bs the array of BS's filled with data on locations and neighbours
	 * @returns the id of the BS which is closest to the ES
	 */
	public static int findBaseStation(EndStation e, BaseStation[] bs)
	{
		int counter=0; double minDistance=9999; int minIndex=9999;
		//loop through all the basestations until we get one close enough to the endstation
		while(bs[counter]!=null)
		{
			//see if the distance from the BS to ES is within range
			double distance = getDistance(e.getX(),bs[counter].getX(),e.getY(),bs[counter].getY());
			if(distance <= Simulation.BS_RANGE && distance < minDistance)
			{	minDistance = distance; minIndex = counter; }
			counter++;
		}		
		return minIndex;
	}
  
  /*
	 * Generates the neighbours for each BS in the bs array
	 * @param bs the array of the BS's to add the data to
	 * @return the neighbour data added to the array data
	 */
	public static BaseStation[] generateNeighbours(BaseStation bs[])
	{
	  int currentBS = 0;
	  //loop through all BS to generate their neighbours
	  while(currentBS < Simulation.MAX_BASESTATIONS && bs[currentBS]!=null)
	  {
	    int potentialNeighbour=0;
	    //loop through all potential neighbours to check distance
	    while(bs[potentialNeighbour]!=null)
	    {
	      //make sure we dont compare against itself
	      if(potentialNeighbour < Simulation.MAX_BASESTATIONS && potentialNeighbour != currentBS)
	      {
	        if(getDistance(bs[currentBS].getX(), bs[potentialNeighbour].getX(), bs[currentBS].getY(), bs[potentialNeighbour].getY()) < Simulation.INTER_BS_RANGE )
	        {
	          bs[currentBS].addNeighbour(potentialNeighbour);
	        }
        }
	      potentialNeighbour++;
	    }
	    currentBS++;
	  }
	  
	  return bs;
	}
	
	/*
	 * Generates the locations of the BS's in the wireless network
	 * @param bs The array of BS's to put the data into
	 * @return A filled array of BS's with all the data required for the simulation except for the neighbours
	 */
	public static BaseStation[] generateBSLocations(BaseStation bs[]) 
	{
		int numBaseStations = 0; double x=0, y=0;	boolean even = true;	// used to control whether the BS is indented in position
		
		//0.8 * R is the actual separation of the BS's with respect to the diameter of the circle
		double separationDistanceX = 2 * Math.sqrt(0.8*Simulation.BS_RANGE);	//on the x axis each is separated by 2 * R
		double separationDistanceY = Simulation.BS_RANGE + ( 0.5 * Math.sqrt(0.8*Simulation.BS_RANGE) ); //on y axis each is separated by R + (0.5 * R)
		
		//add each row of BS's
		while(y < Simulation.MAX_Y + separationDistanceY)
		{
			//control the indentation of the BS's
			if(even)
			{	x = 0; even = false; }
			else
			{	x = separationDistanceX / 2; even = true;	}
			
			//add each col of BS's
			while(x < Simulation.MAX_X + separationDistanceY)
			{
				BaseStation tmp = new BaseStation(numBaseStations, x,y);
				bs[numBaseStations] = tmp;
				numBaseStations++;
				
				//Check to make sure the array isnt going out of bounds
				if(numBaseStations > Simulation.MAX_BASESTATIONS)
				{
				  System.out.println("ERROR: OUT OF ARRAY LOCATIONS FOR BASESTATIONS, INCREASE SIZE OF MAX_BASESTATIONS");
				  System.exit(1);
				}
				 
				x = x + separationDistanceX;
			}
			y = y + separationDistanceY;
		}
		return bs;
	}
	
	/*
	 * Finds the distance between two points P1(x1,y1) and P2(x2, y2)
	 * @param x1 The first x point
	 * @param x2 The second x point
	 * @param y1 The first y point
	 * @param y2 The first y point
	 * @return the distance between P1 and P2
	 */
	public static double getDistance(double x1, double x2, double y1, double y2)
	{
		return Math.sqrt(Math.pow(x2-x1,2) + Math.pow(y2-y1, 2));
	}
	
	/*
	 * Returns the id of the neighbour closest to the destination given the currentLocation and destination
	 * @param bs The array of BS's filled with data on positions and neighbours
	 * @param currentBS the location the packet is currently at
	 * @param endBS the destination the packet is travelling to
	 * @return the nearest neighbour on the path to the destination
	 */
	public static int getNearestNeighbour(BaseStation bs[], int currentBS, int endBS)
	{
	  double minDistance = 9999;
	  int minId = 9999;
	  
	  int counter=0;
	  
	  //loop through all the neighbours for the given node
	  while(counter < BaseStation.MAX_NEIGHBOURS)
	  {
	    int neighbourToCheck = bs[currentBS].getNeighbour(counter);
	    
	    //only check if the neighbour exists (some nodes on have 2 or 3 neighbours if on an edge of the network
	    if(neighbourToCheck != -1)
	    {
	      //get distance from endBS to current neighbour we are checking
	      double tmpDistance = getDistance(bs[endBS].getX(), bs[neighbourToCheck].getX(), bs[endBS].getY(), bs[neighbourToCheck].getY());
	      
	      //replace the current min with the new min
	      if(tmpDistance < minDistance )
	      {
	        minDistance = tmpDistance;
	        minId = neighbourToCheck;
	      }
	    }
	    counter++;
	  }
	  
	  //error if this happens, couldnt find a min distance neighbour for some reason
	  if(minId == 9999)
	    return -1;
	  else //return the minimum distance from dest neighbour
	    return minId;
	}
}
