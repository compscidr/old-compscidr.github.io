/**
 * @(#)SimulationTools.java
 *
 * @author Jason Ernst
 * @description The class provides much of the functionality required for the simulation but separated out of the Simulation
 * class itself to improve readability.
 * @version 2.00 2008/4/12
 */
class SimulationTools
{
  public SimulationTools()
  {}
    
	/*
	 * Generates the locations of the nodes within the switch. Hardcoded for now.
	 * @param bs The array of BS's to put the data into
	 * @return A filled array of BS's with all the data required for the simulation, ie) neighbours etc.
	 */
	public static BaseStation[] generateBSLocations(BaseStation bs[]) 
	{
	  int numBaseStations = 0;
		double x=0, y=0;
		
		//define the baseStations
													//id, x, y
		bs[0] = new BaseStation(0, 0, 0);
		bs[1] = new BaseStation(1, 0, 1);
		bs[2] = new BaseStation(2, 0, 2);
		bs[3] = new BaseStation(3, 1, 0);
		bs[4] = new BaseStation(4, 1, 2);
		bs[5] = new BaseStation(5, 2, 0);
		bs[6] = new BaseStation(6, 2, 1);
		bs[7] = new BaseStation(7, 2, 2);
		bs[8] = new BaseStation(8, 3, 0);
		bs[9] = new BaseStation(9, 3, 2);
		bs[10] = new BaseStation(10, 4, 0);
		bs[11] = new BaseStation(11, 4, 1);
		bs[12] = new BaseStation(12, 4, 2);
		bs[13] = new BaseStation(13, 5, 0);
		bs[14] = new BaseStation(14, 5, 2);
		bs[15] = new BaseStation(15, 6, 0);
		bs[16] = new BaseStation(16, 6, 1);
		bs[17] = new BaseStation(17, 6, 2);
		bs[18] = new BaseStation(18, 7, 0);
		bs[19] = new BaseStation(19, 7, 2);
	
		//Set up neighbours
		bs[0].addNeighbour(1);
		bs[0].addNeighbour(6);
				
		bs[1].addNeighbour(2);
		bs[1].addNeighbour(4);
		bs[1].addNeighbour(12);
		bs[1].addNeighbour(14);
				
		bs[3].addNeighbour(1);
		bs[3].addNeighbour(6);
		
		bs[5].addNeighbour(1);
		bs[5].addNeighbour(6);
		
		bs[6].addNeighbour(7);
		bs[6].addNeighbour(9);
		bs[6].addNeighbour(17);
		bs[6].addNeighbour(19);
		
		bs[8].addNeighbour(1);
		bs[8].addNeighbour(6);
		
		bs[10].addNeighbour(11);
		bs[10].addNeighbour(16);
		
		bs[11].addNeighbour(12);
		bs[11].addNeighbour(14);
		bs[11].addNeighbour(2);
		bs[11].addNeighbour(4);
		
		bs[13].addNeighbour(11);
		bs[13].addNeighbour(16);
		
		bs[15].addNeighbour(11);
		bs[15].addNeighbour(16);
		
		bs[16].addNeighbour(7);
		bs[16].addNeighbour(9);
		bs[16].addNeighbour(17);
		bs[16].addNeighbour(19);
		
		bs[18].addNeighbour(11);
		bs[18].addNeighbour(16);

		
		return bs;
	}

  /*
   * A method to return the correct neighbour for a given node in the switch so that
   * we can determine where to forward the packets to.
   * @param bs The array of BS's with all the data required for the simulation
   * @param currentBS The id of the BS where the packet is currently located
   * @param endBS The id of the BS where the packet is headed
   * @return The id of the correct neighbour BS to send the packet to next
   */
	public static int getCorrectNeighbour(BaseStation bs[], int currentBS, int endBS)
	{
	  //we have arrived at the end
	  if(currentBS == endBS)
	  	return endBS;
	  //we need a hop
	  else
	  {	
	    int neighbours[] = new int[BaseStation.MAX_NEIGHBOURS];
	    neighbours = bs[currentBS].getNeighbours();
	    int count = 0;
	    while(neighbours[count]!=-1)
	  	{
	  	  count++;
	  	}
	  	//we have arrived at the end but not at the correct endBS
	  	if(count == 0)
	  		return -1;
	  	//check for two neighbours(start of the switch)
	  	else if(count == 2)
	  	{
	  	  int n1 = neighbours[0];
	  	  int n2 = neighbours[1];
	  	  
	  	  if(getCorrectNeighbour(bs, n1, endBS) == endBS)
	  	  	return n1;
	  	  else
	  	  	return n2;
	  	}
	  	//check for 4 neighbours (middle of switch)
	  	else
	  	{
	  	  int n1 = neighbours[0];
	  	  int n2 = neighbours[1];
	  	  int n3 = neighbours[2];
	  	  int n4 = neighbours[3];
	  	  
	  	  if(getCorrectNeighbour(bs, n1, endBS) == endBS)
	  	  	return n1;
	  	  else if(getCorrectNeighbour(bs, n2, endBS) == endBS)
	  	    return n2;
	  	  else if(getCorrectNeighbour(bs, n3, endBS) == endBS)
	  	    return n3;
	  	  else
	  	  	return n4;
	  	}
	  }
	}
}
