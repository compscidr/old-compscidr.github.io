/**
 * @(#)EventQueue.java
 *
 * @author Jason Ernst
 * @description EventQueue implementation for the simulation
 * @version 2.00 2008/4/12
 */
class EventQueue
{
  //define constants
  private final static int MAX_EVENTS = 100;

  //define private variables
  private Event[] EQ = new Event[MAX_EVENTS];
  private int last;
  
  /*
   * Construct a new EventQueue
   */
  public EventQueue()
  {
    last = -1;
  }
  
  /*
   * Dumps the contents of the EQ to the screen
   */
  public void display()
  {
    System.out.println("Dumping EQ: ");
    for(int x=0;x<MAX_EVENTS;x++)
      if(EQ[x]!=null)
        EQ[x].display();
  }
  
  /*
   * Checks if there is space in the EQ for another event
   * @return true or false depending on if there is room in the EQ
   */
  public boolean isRoom()
  {
    if(last+1 < MAX_EVENTS)
      return true;
    else
      return false;
  }
  
  /*
   * Inserts an event into the EQ if there
   * is room
   * @param e the Event to add to the queue
   */
  public void insert(Event e)
  {
    if(last+1 == MAX_EVENTS)
  		OverFlow();
  	EQ[++last] = e;  
  }
  
  /*
   * Removes the event with the lowest time
   * @return the Event with the lowest time
   */
  public Event removeMin()
  {
    if(last==-1)
   	  return null;
    int min = last;
    for(int i=0; i<last;i++)
   	  if(EQ[i].getTime() < EQ[min].getTime())
   		  min = i;
    Event tmp = EQ[min];
    EQ[min] = EQ[last--];
    return tmp;
  }
  
  /*
   * This method is called when an insert occurs without room in the queue
   */ 
  private void OverFlow()
  {
    System.out.println("Error, trying to add more events than we have room for in the Event Queue.");
    System.exit(0);
  }
}
