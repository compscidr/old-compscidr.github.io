import java.util.*;

/**
 * @(#)Simulation.java
 *
 * @author Jason Ernst
 * @description CS6650 - Computer Networks: Project 2: Discrete Event Simulation of an 8x8 banyan switch.
 * @version 2.00 2008/4/12
 */
class Simulation
{
  //constant values
  private final static double MEAN = 0.0001;            //avg time between packets
  private final static int NUM_PACKETS = 10000;
  
  public static final int MAX_BASESTATIONS = 500; //max # of BS's to allocate memory for
  
  //private variables
  private static EventQueue EQ = new EventQueue();
  private static BaseStation bs[] = new BaseStation[MAX_BASESTATIONS];

  /*
   * Main Simulation Method
   */
  public static void main(String args[])
  {
    //variables for main
    Event tmp=null; Event min=null;
    double now=0; double delay=0; double highDelay=0; double lowDelay=0;
    int packetCounter=0; int dropCounter=0; int successCounter=0;
      
    System.out.println("Starting Simulation with MEAN = " + MEAN + " ...");
    /********************************************/
    
    //create the basestations and their neighbours
		bs = SimulationTools.generateBSLocations(bs); 
    
    tmp = generatePacket(now);
    EQ.insert(tmp);
    packetCounter++;
    
    //main simulation loop
    //continues until no more events are in the event queue
    while((min=EQ.removeMin())!=null)
    {
      int type = min.getType();
      int source; int destination; int neighbour;
      Random rand = new Random();
      
      now = min.getTime();
      
      source = min.getSource();
      destination = min.getDestination();
      
      //handle each type of event differently      
      switch(type)
      {
        case Event.HOP:
          //System.out.print("Hop Event: ");
          //min.display();
          
          //we have arrived at dest
          if(source == destination)
          {
            //System.out.println("  DESTINATION REACHED, changing to success event");
            //change type to SUCCESS, increment time and reinsert into queue
            min.setType(Event.SUCCESS);
            min.setTime(min.getTime() + 1);
            EQ.insert(min);
            min.addDelay(1);
          }
          else //hop to neighbour
          {
            //check to make sure BS is free to hop into it
            neighbour = SimulationTools.getCorrectNeighbour(bs, source, destination);
            if(bs[neighbour].getBuffer()==-1)
            {
              //System.out.println("  Neighbour CLEAR, putting destination into buffer of neighbour");
              bs[neighbour].setBuffer(destination);
              bs[source].clearBuffer();
            
              //increment time, change source and reinsert into queue
              min.setSource(neighbour);
              min.setTime(min.getTime() + 1);
              EQ.insert(min);
              min.addDelay(1);
            } 
            else //timeout 
            {
              //System.out.print("  Neighbour BUSY:");
              if(min.getNumTimeOuts() < 0)
              {
                //System.out.println("timeout");
                double timeout = rand.nextDouble() * 10 + 1; //random timeout from 1 to 10s
                min.addTimeOut(timeout);
                min.setTime(min.getTime() + timeout);
                EQ.insert(min);
              }
              else
              {
                //System.out.println("out of timeouts, changing to drop event");
                //change event type to drop and reinsert into queue
                min.setType(Event.DROP);
                EQ.insert(min); 
              }
            }//end else if buffer is emtpy
          }//end else if source==dest  
        break;
        case Event.NEW_PACKET:
          //System.out.print("New Packet Event: ");
          //min.display();
          
          //check to make sure the BS is free before we fill buffer
          if(bs[source].getBuffer()==-1)
          {
            //System.out.println("  Source CLEAR, putting destination into buffer of source");
            bs[source].setBuffer(destination);
            
            //change type to HOP, increment time and reinsert into queue
            min.setType(Event.HOP);
            min.setTime(min.getTime() + 1);
            EQ.insert(min);
            min.addDelay(1);
          }
          else
          {
            packetCounter--;//remove packet because source is busy
            //System.out.println("  Source BUSY");
          }
        break;
        case Event.SUCCESS:
          //System.out.print("Success Event: ");
          //min.display();
          
          successCounter++;
          bs[source].clearBuffer();
          
          highDelay = highDelay + min.getDelay();
          lowDelay = lowDelay + min.getDelay();
        break;
        case Event.DROP:
          //System.out.print("Drop Event: ");
          //min.display();
          
          dropCounter++;
          bs[source].clearBuffer();
          
          highDelay = highDelay + min.getDelay();
        break;
        default: 
          System.out.println("There was a problem handling the event, most likely an improper event type");
          System.exit(0);
        break;
      }
            
      //Generate new packets
      if(packetCounter < NUM_PACKETS && EQ.isRoom())
      {
        tmp = generatePacket(now);
        EQ.insert(tmp);
        packetCounter++;
      }
    }
    
    /********************************************/
    
    double avgHighDelay = highDelay / (double)packetCounter;
    double avgLowDelay = lowDelay / (double)successCounter;
    double offeredLoad = (double)packetCounter / now;
    double effectiveThroughput = (double)successCounter / now;
    
    System.out.println("Simulation Complete.");

    //output statistics
    System.out.println("Total time: " + now);
    System.out.println("Packets Generated: " + packetCounter);
    System.out.println("Success Packets: " + successCounter);
    System.out.println("Dropped Packets: " + dropCounter);
    System.out.println("High delay: " + highDelay + " Avg High Delay: " + avgHighDelay);
    System.out.println("Low delay: " + lowDelay + "Avg Low Delay: " + avgLowDelay);
    System.out.println("Offered Load: " + offeredLoad);
    System.out.println("Effective Throughput: " + effectiveThroughput);
  }
  
  /*
   * Generates new packets at a given time
   * @param now The time the packet should be generated at
   * @return A "NEW_PACKET" event with time now
   */
  private static Event generatePacket(double now)
  {
    double time = now + poisson(MEAN);;
    int source;
    int destination;
    Random rand = new Random();
    
    //generate source
    int s = (int)(rand.nextDouble() * 8);
    source = -1;
    switch(s)
    {
      case 0: source=0; break;
      case 1: source=3; break;
      case 2: source=5; break;
      case 3: source=8; break;
      case 4: source=10; break;
      case 5: source=13; break;
      case 6: source=15; break;
      case 7: source=18; break;
      default: System.out.println("Error Generating Source, see generatePacket function."); System.exit(0); break;  
    }    
    //generate destination
    destination = -1;
    int d = (int)(rand.nextDouble() * 8);
    switch(d)
    {
      case 0: destination=2; break;
      case 1: destination=4; break;
      case 2: destination=7; break;
      case 3: destination=9; break;
      case 4: destination=12; break;
      case 5: destination=14; break;
      case 6: destination=17; break;
      case 7: destination=19; break;
      default: System.out.println("Error Generating Destination, see generatePacket function."); System.exit(0); break;  
    }
    return new Event(time, Event.NEW_PACKET, source, destination);
  }
  
  /*
   * A method to help generate the next arrival time in a simulation using a
   * possion process / exponential distribution
   * @param MEAN the average inter-arrival time for the entire simulation
   * @return The time between the previous event and the current event
   */
  private static double poisson (double MEAN)
 	{
    return ( (-1) * MEAN*Math.log(Math.random()) );
 	}
}
